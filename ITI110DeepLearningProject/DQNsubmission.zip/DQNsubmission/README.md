# DQN Carla
This project is based on repository https://github.com/EmanueleBenedettini/DQN-Autonomous-Vehicle-on-CARLA and all his dependencies. 

Hyperparameters have been set to the optimal ones defined in experiment 5 of the report (DQN section).

## Commands

- standard learning run -> **rl_car_driver.py**
- restore old run -> **rl_car_driver.py --model run-out-xxxx-xx-xx-xx-xx-xx**
- run in evaluation mode -> **rl_car_driver.py --evaluate True --model run-out-xxxx-xx-xx-xx-xx-xx**

## Dependencies

- CARLA 0.9.11
- python 3.7
- TensorFlow 2.x

On Windows, copy  CARLA_Sim_Launcher/Launcher.bat into your folder containig the downloaded simulator (location of CarlaUE4.exe).  


## Demo
https://youtu.be/G1Y9H1iqY8c
https://youtu.be/tDV37bbLN9w
https://youtu.be/L5CRrl758Yc
